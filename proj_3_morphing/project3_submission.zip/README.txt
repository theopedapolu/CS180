Name: Theophilus Pedapolu
SID: 3035826494
Email: theopedapolu@berkeley.edu

Description of code/face_morphing.ipynb:
The only code file in this submission is face_morphing.ipynb, a jupyter notebook that contains all the code used to generate the images
in the webpage. The code for each part of the project is in the corresponding code section in the notebook, labeled appropriately by a header.
For each section, the notebook pulls images from the current directory and performs operations like morphing or averaging. It then saves the
important images that are later in the webpage into the current directory. For instance, for the morph sequence part, all the frames of the 
sequence are computed and saved to the current directory